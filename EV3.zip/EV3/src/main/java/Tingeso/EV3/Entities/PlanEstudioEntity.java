package Tingeso.EV3.Entities;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "planestudios")
@Data

@NoArgsConstructor
@AllArgsConstructor
public class PlanEstudioEntity {
    private int cod_carr;
    @Id
    private String cod_plan;
    private int nivel;
    private int cod_asig;
    private String nom_asig;
}
